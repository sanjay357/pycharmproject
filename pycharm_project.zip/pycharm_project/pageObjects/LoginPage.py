from selenium import webdriver


class LoginPage(object):
    textbox_username_xpath = "/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-login-page/mat-card/div[1]/input"
    textbox_password_xpath = "/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-login-page/mat-card/div[2]/input"
    button_login_xpath = "/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-login-page/mat-card/button"

    def __init__(self, driver):
        self.driver = driver

    def set_user_name(self, username):
        self.driver.find_element_by_xpath(self.textbox_username_xpath).send_keys(username)

    def set_password(self, password):
        self.driver.find_element_by_xpath(self.textbox_password_xpath).send_keys(password)

    def click_login(self):
        self.driver.find_element_by_xpath(self.button_login_xpath).click()