from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pytest


@pytest.fixture(scope="class")
def setup():
    options = Options()
    options.headless = True
    driver = webdriver.Chrome(executable_path='./drivers/chromedriver.exe', options=options)
    return driver
