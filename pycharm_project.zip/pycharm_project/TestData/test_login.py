from pageObjects.LoginPage import LoginPage
from pageObjects.conftest import setup
import pytest
from selenium import webdriver
import logging
import time
from utilities.customLogger import LogGen



class TestLogin:
    baseURL = "https://localhost:44347"
    username = "Sanjay"
    password = "kumar"
    logger = LogGen.loggen()
  
    def test_homepage_title(self, setup):
        self.logger.info("Test case 1 start's")
        self.driver = setup
        time.sleep(15)
        self.driver.get(self.baseURL)
        act_title = self.driver.title
        time.sleep(10)
        # self.driver.close()
        if act_title == "B/S/H":
            assert True
            self.driver.save_screenshot(".\\screenshot\\" + "test_homepage_title.png")
            self.logger.info("Test case 1 passed")
        else:
            assert False
            self.logger.info("test case 1 failed")
            self.driver.save_screenshot(".\\screenshot\\"+"test_homepage_title.png")
    def test_login(self, setup):
        time.sleep(5)
        self.logger.info("Test case 2 start's")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.lp = LoginPage(self.driver)
        self.lp.set_user_name(self.username)
        self.lp.set_password(self.password)
        time.sleep(10)
        self.lp.click_login()
        time.sleep(40)
        act_title = self.driver.title
        self.driver.close()
        if act_title == "B/S/H":
            assert True
            self.logger.info("Test case 2 passed")
        else:
            assert False
            self.logger.info("Test case 2 failed")
            self.driver.save_screenshot(".\\screenshot\\" + "test_login.png")
    